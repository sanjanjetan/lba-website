<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo t("Picture Removed") ?></h1>
<div class="Info">
    <?php echo t('Picture was successfully removed.'); ?>
</div>