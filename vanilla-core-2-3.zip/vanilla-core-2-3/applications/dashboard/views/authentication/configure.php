<div class="AuthenticationConfigure Slice" rel="dashboard/authentication/configure">
    <div class="Info">
        <?php echo $this->data('ConfigureMessage'); ?>
    </div>
</div>
