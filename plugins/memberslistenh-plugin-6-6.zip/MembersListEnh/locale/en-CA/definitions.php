<?php if (!defined('APPLICATION')) exit();
$Definition['Members'] = "Members";
$Definition['Members List Enhanced'] = "Members List Enhanced";
$Definition['banned'] = "Banned";
$Definition['Photo'] = "Photo";
$Definition['Username'] = "User Name";
$Definition['Thanks'] = "Thanks";
$Definition['Karma'] = "Karma";
$Definition['Likes'] = "Likes";
$Definition['User ID'] = "User ID";
$Definition['Roles'] = "Roles";
$Definition['First Visit'] = "First Visit";
$Definition['Last Visit'] = "Last Visit";
$Definition['Email'] = "Email";
$Definition['Last IP Address'] = "Last IP Address";
$Definition['Visits'] = "Visits";
$Definition['Discussion Count'] = "Discussion Count";
$Definition['Comment Count'] = "Comment Count";

