<?php if (!defined('APPLICATION')) exit();

/*
 * Begin CloudyPremiumMobile Theme
*/
$ThemeInfo['CloudyPremiumMobile'] = array(
   'Name' => 'CloudyPremiumMobile',
   'Description' => "Cloudy is Fully Responsive,Retina Ready and Bootstrap Based Vanilla Theme. It’s very clean and light. Cloudy is self development theme without core changes So it’s Fast and Content-based! <br /><br />Copyright Removal Allowed For Premium Versions But You cannot redistribute, resell, lease, license, sub-license or offer our resources to any third party.",
   'Version' => '1.3',
   'Author' => "ThemeSteam.com",
   'AuthorEmail' => 'info@themesteam.com',
   'AuthorUrl' => 'http://www.themesteam.com',
   'IsMobile'=>true,    

);